package com.adobe.adms;

import java.util.Hashtable;

import android.app.Activity;

import com.adobe.adms.measurement.ADMS_Measurement;

public class TrackingHelper {

	private static final String TRACKING_RSID = "YOUR_REPORTSUITEID";
	private static final String TRACKING_SERVER = "YOUR_TRACKINGSERVER";

	public static void startActivity(Activity activity) {
		ADMS_Measurement measurement = ADMS_Measurement.sharedInstance(activity);
		measurement.startActivity(activity);
	}

	public static void stopActivity() {
		ADMS_Measurement measurement = ADMS_Measurement.sharedInstance();
		measurement.stopActivity();
	}

	public static void configureAppMeasurement(Activity activity) {
		ADMS_Measurement measurement = ADMS_Measurement.sharedInstance(activity);
		measurement.configureMeasurement(TRACKING_RSID, TRACKING_SERVER);
	}
	
	
	// Examples of Custom Event and AppState Tracking
	public static void trackCustomEvents (String events) {
		Hashtable<String, Object> contextData = new Hashtable<String, Object>();
		contextData.put("contextKey", "value");
		
		ADMS_Measurement measurement = ADMS_Measurement.sharedInstance();
		measurement.trackEvents(events, contextData);
	}
	
	public static void trackCustomAppState (String appState) {
		Hashtable<String, Object> contextData = new Hashtable<String, Object>();
		contextData.put("contextKey", "value");

		ADMS_Measurement measurement = ADMS_Measurement.sharedInstance();
		measurement.trackAppState(appState, contextData);
	}
	

}
